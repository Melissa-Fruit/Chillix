
var MONSTA_LATEST_VERSION = "2.10.2";
if (typeof monstaLatestVersionCallback === "function")
	monstaLatestVersionCallback("2.10.2");
